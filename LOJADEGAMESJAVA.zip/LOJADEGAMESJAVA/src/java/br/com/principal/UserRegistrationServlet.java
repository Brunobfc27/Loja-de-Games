package br.com.principal;

import com.example.gamestore.connection.DatabaseConnection;
import com.example.gamestore.dao.UserDAO;
import com.example.gamestore.model.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserRegistrationServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;

    public UserRegistrationServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter writer = response.getWriter();
        String name = request.getParameter("nome_cad");
        String email = request.getParameter("email_cad");
        String password = request.getParameter("senha_cad");
        String location = request.getParameter("location");

        Connection con;
        try {
            con = DatabaseConnection.getConnection();

            User user = new User();
            user.setName(name);
            user.setEmail(email);

            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(password.getBytes());

            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b & 0xff));
            }

            user.setPassword(sb.toString());

            UserDAO dao = new UserDAO(con);
            dao.addUser(user);
            request.setAttribute("email", user.getEmail());
            request.getRequestDispatcher(location + ".jsp").forward(request, response);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(UserRegistrationServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
