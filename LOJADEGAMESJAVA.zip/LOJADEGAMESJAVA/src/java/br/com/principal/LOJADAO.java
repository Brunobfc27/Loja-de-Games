/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.principal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class LOJADAO {
    private Connection con;
    public LOJADAO(Connection con){
        this.con = con;
    }
    public void adicionar (Loja c) throws SQLException{
        String sql = "insert into categoria(nome_categoria, descricao_categoria"
                + ", id_usuario_fk) values (?,?,?)";
        
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            
            stmt.setString(1, c.getNome_categoria());
            stmt.setString(2, c.getDescricao_categoria());
            stmt.setInt(3, c.getId_usuario_fk());
            
            stmt.execute();
            stmt.close();
        } catch (SQLException e){
            e.printStackTrace();
        } finally{
            con.close();
        }
    }
    public void atualizar (Loja c) throws SQLException{
        String sql = "update categoria set nome_categoria= ? , descricao_categoria = ? ,"
                + " id_usuario_fk = ? where id_usuario = ?";
        
        try {
            PreparedStatement stmt = con.prepareStatement(sql);
            
            stmt.setString(1, c.getNome_categoria());
            stmt.setString(2, c.getDescricao_categoria());
            stmt.setInt(3, c.getId_usuario_fk());
            stmt.setInt(4, c.getId_categoria());
            
            stmt.execute();
            stmt.close();
        } catch (SQLException e){
            e.printStackTrace();
        } finally{
            con.close();
        }
    }
}
