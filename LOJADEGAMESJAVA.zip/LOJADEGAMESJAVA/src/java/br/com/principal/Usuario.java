/*
 * Bem-vindo à Loja de Games do Universo Virtual!
 * Todos os direitos reservados.
 */

package br.com.principal;

public class Usuario {
    private int idUsuario;
    private String nomeUsuario;
    private String senha;
    private String email;
    private int statusAtivacao; // Status de ativação da conta (0 - inativo, 1 - ativo)
    private int nivelAcesso; // Nível de acesso do usuário (0 - usuário padrão, 1 - administrador)

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public int getStatusAtivacao() {
        return statusAtivacao;
    }

    public void setStatusAtivacao(int statusAtivacao) {
        this.statusAtivacao = statusAtivacao;
    }

    public int getNivelAcesso() {
        return nivelAcesso;
    }

    public void setNivelAcesso(int nivelAcesso) {
        this.nivelAcesso = nivelAcesso;
    }
}
