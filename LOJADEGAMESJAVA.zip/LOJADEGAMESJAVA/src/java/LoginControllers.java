import com.example.gamestore.connection.DatabaseConnection;
import com.example.gamestore.model.Notification;
import com.example.gamestore.dao.NotificationDAO;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginController extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String emailBuscado = "";
            String nomeBuscado = "";
            String senhaBuscada = "";
            int idBuscado = 0;
            Connection con;
            String email = request.getParameter("email_login");
            String senha = request.getParameter("senha_login");
            String sql = "SELECT * FROM usuario WHERE email_usuario = ? AND senha_usuario = ?";
            
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(senha.getBytes());
            
            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b & 0xff));
            }
            senha = sb.toString();
            try {
                con = DatabaseConnection.getConnection();
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setString(1, email);
                stmt.setString(2, senha);
                
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    emailBuscado = rs.getString("email_usuario");
                    senhaBuscada = rs.getString("senha_usuario");
                    nomeBuscado = rs.getString("nome_usuario");
                    idBuscado = rs.getInt("id_usuario");
                }
                rs.close();
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            
            if (emailBuscado.equals(email) && senhaBuscada.equals(senha)) {
                HttpSession session = request.getSession();
                session.setAttribute("id", idBuscado);
                session.setAttribute("email", email);
                session.setAttribute("nome", nomeBuscado);
                
                con = DatabaseConnection.getConnection();
                Notification n = new Notification(idBuscado);
                NotificationDAO dao = new NotificationDAO(con);
                session.setAttribute("notifs", dao.countNotifications(n));
                request.getRequestDispatcher("logged_in.jsp").forward(request, response);
            } else {
                request.getRequestDispatcher("user_error.jsp").forward(request, response);
            }
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
