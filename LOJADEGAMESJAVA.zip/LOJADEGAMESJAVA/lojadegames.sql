drop schema if exists GameStore;
create schema if not exists GameStore default character set utf8;
use GameStore;

create table if not exists GameStore.roles (
    id_role int not null auto_increment,
    role_name varchar(15) not null,
    primary key (id_role)
) engine = InnoDB;

create table if not exists GameStore.users (
    id_user int not null auto_increment,
    username varchar(50) not null,
    email varchar(50) not null,
    password varchar(64) not null,
    is_active boolean not null,
    role_id int not null,
    primary key (id_user),
    foreign key (role_id) references roles(id_role)
) engine = InnoDB;

create table if not exists GameStore.games (
    id_game int not null auto_increment,
    user_id int not null,
    game_name varchar(80) not null,
    game_description varchar(2000),
    game_image varchar(500) default 'img/default_game.jpg',
    primary key (id_game),
    foreign key (user_id) references users(id_user)
) engine = InnoDB;

create table if not exists GameStore.categories (
    id_category int not null auto_increment,
    user_id int not null,
    category_name varchar(20) not null,
    category_description varchar(300),
    primary key (id_category),
    foreign key (user_id) references users(id_user)
) engine = InnoDB;

create table if not exists GameStore.game_categories (
    category_id int not null,
    game_id int not null,
    primary key (category_id, game_id),
    foreign key (category_id) references categories(id_category),
    foreign key (game_id) references games(id_game)
) engine = InnoDB;

create table if not exists GameStore.chats (
    id_chat int not null auto_increment,
    user1_id int not null,
    user2_id int not null,
    primary key (id_chat),
    foreign key (user1_id) references users(id_user),
    foreign key (user2_id) references users(id_user)
) engine = InnoDB;

create table if not exists GameStore.chat_messages (
    id_message int not null auto_increment,
    user_id int not null,
    chat_id int not null,
    message_text varchar(300) not null,
    message_timestamp datetime default(now()),
    primary key (id_message),
    foreign key (user_id) references users(id_user),
    foreign key (chat_id) references chats(id_chat)
) engine = InnoDB;

create table if not exists GameStore.tags (
    id_tag int not null auto_increment,
    tag_name varchar(11) not null,
    primary key (id_tag)
) engine = InnoDB;

create table if not exists GameStore.user_tags (
    tag_id int not null,
    user_id int not null,
    primary key (tag_id, user_id),
    foreign key (user_id) references users(id_user),
    foreign key (tag_id) references tags(id_tag)
) engine = InnoDB;

create table if not exists GameStore.game_tags (
    tag_id int not null,
    game_id int not null,
    primary key (tag_id, game_id),
    foreign key (game_id) references games(id_game),
    foreign key (tag_id) references tags(id_tag)
) engine = InnoDB;

create table if not exists GameStore.comments (
    id_comment int not null auto_increment,
    user_id int not null,
    game_id int not null,
    comment_text varchar(300) not null,
    comment_timestamp datetime default(now()),
    primary key (id_comment),
    foreign key (user_id) references users(id_user),
    foreign key (game_id) references games(id_game)
) engine = InnoDB;

create table if not exists GameStore.notifications (
    id_notification int not null auto_increment,
    user_id int not null,
    notification_text varchar(300) not null,
    notification_timestamp datetime default(now()),
    primary key (id_notification),
    foreign key (user_id) references users(id_user)
) engine = InnoDB;

insert into GameStore.roles (role_name) values 
    ("Admin"),
    ("Moderator"),
    ("Customer");

insert into GameStore.users (username, email, password, is_active, role_id) values 
    ("admin", "admin@admin.com", "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918", true, 1),
    ("moderator", "moderator@user.com", "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918", true, 2),
    ("customer", "customer@user.com", "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918", true, 3);

insert into GameStore.categories (user_id, category_name, category_description) values 
    (1, "Action", "Action games"),
    (2, "Adventure", "Adventure games"),
    (3, "Puzzle", "Puzzle games");

insert into GameStore.tags (tag_name) values
    ("New"),
    ("Popular"),
    ("Sale"),
    ("Exclusive");

insert into GameStore.user_tags (tag_id, user_id) values
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 1);

insert into GameStore.notifications (user_id, notification_text) values 
    (1, "Welcome to the Game Store!"),
    (2, "New games added!"),
    (3, "Check out our latest discounts!");

select * from GameStore.users;
select * from GameStore.games;
select * from GameStore.categories;
select * from GameStore.tags;
select * from GameStore.comments;
select * from GameStore.notifications;
